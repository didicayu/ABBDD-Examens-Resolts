public interface Component {
    public void accept(ComponentVisitor visitor);
}
