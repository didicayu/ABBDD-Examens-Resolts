import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Set;

public class Item implements Product{

    private BigDecimal price;

    public Item(BigDecimal price) {
        checkGreaterThanZero(price);

        this.price = price.setScale(2, RoundingMode.HALF_UP);
    }

    private void checkGreaterThanZero(BigDecimal price) {
        if(price.compareTo(BigDecimal.ZERO) <= 0){
            throw new IllegalArgumentException("Price must be greater than zero");
        }
    }

    @Override
    public BigDecimal getPrice() {
        return this.price;
    }

    public void setPrice(BigDecimal newPrice) {
        newPrice = newPrice.setScale(2, RoundingMode.HALF_UP);
        checkGreaterThanZero(newPrice);
        this.price = newPrice;
    }

    @Override
    public void checkMinItemPrice(BigDecimal minItemPrice){
        checkGreaterThanZero(minItemPrice);

        if(this.price.compareTo(minItemPrice) < 0){
            this.price = minItemPrice.setScale(2, RoundingMode.HALF_UP);
        }
    }

    @Override
    public long countItemsBelowMinPrice(BigDecimal minPrice, Set<Product> visitedProducts) {
        return this.price.compareTo(minPrice) < 0 ? 1 : 0;
    }

    @Override
    public void accept(ProductVisitor visitor) {
        visitor.visit(this);
    }
}
