import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class Pack implements Product{

    private List<Product> products;

    public Pack() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        if (product == null) {
            throw new NullPointerException("Product is null");
        }

        products.add(product);
    }

    @Override
    public BigDecimal getPrice() {
        return products.stream()
                .map(Product::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);

    }

    public List<Product> getProducts() {
        return Collections.unmodifiableList(products);
    }

    @Override
    public void checkMinItemPrice(BigDecimal minItemPrice) {
        products.forEach(product -> product.checkMinItemPrice(minItemPrice));
    }

    @Override
    public long countItemsBelowMinPrice(BigDecimal minPrice, Set<Product> visited){
        visited.add(this);

        long count = 0;

        for (Product product : products){
            if (!visited.contains(product)){
                count += product.countItemsBelowMinPrice(minPrice, visited);
            }
        }
        return count;
    }

    @Override
    public void accept(ProductVisitor visitor) {
        visitor.visit(this);
        for (Product product : products) {
            product.accept(visitor);
        }
    }

}
