public interface ProductVisitor {
    void visit(Item item);
    void visit(Pack pack);
}
