import java.math.BigDecimal;
import java.math.RoundingMode;

public class MinPriceUpdaterVisitor implements ProductVisitor {
    private BigDecimal minPrice;

    private MinPriceUpdaterVisitor(BigDecimal minPrice) {
        if (minPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Minimum price must be greater than zero");
        }
        this.minPrice = minPrice.setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public void visit(Item item) {
        if (item.getPrice().compareTo(minPrice) < 0) {
            item.setPrice(minPrice);
        }
    }

    @Override
    public void visit(Pack pack) {
        for (Product product : pack.getProducts()) {
            product.accept(this);
        }
    }

    public static void updatePrices(Product product, BigDecimal minPrice) {
        MinPriceUpdaterVisitor visitor = new MinPriceUpdaterVisitor(minPrice);
        product.accept(visitor);
    }
}
