import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

public interface Product {
    public BigDecimal getPrice();
    public void checkMinItemPrice(BigDecimal minItemPrice);
    long countItemsBelowMinPrice(BigDecimal minPrice, Set<Product> visitedProducts);

    default long countItemsBelowMinPrice(BigDecimal minPrice) {
        Set<Product> visited = new HashSet<>();
        return countItemsBelowMinPrice(minPrice, visited);
    }

    void accept(ProductVisitor visitor);
}
