import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

public class CountItemsBelowMinPriceVisitor implements ProductVisitor {
    private BigDecimal minPrice;
    private int count;
    private Set<Product> visited;

    private CountItemsBelowMinPriceVisitor(BigDecimal minPrice) {
        if (minPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Minimum price must be greater than zero");
        }
        this.minPrice = minPrice;
        this.count = 0;
        this.visited = new HashSet<>();
    }

    @Override
    public void visit(Item item) {
        if (!visited.contains(item)) {
            visited.add(item);
            if (item.getPrice().compareTo(minPrice) < 0) {
                count++;
            }
        }
    }

    @Override
    public void visit(Pack pack) {
        if (!visited.contains(pack)) {
            visited.add(pack);
            for (Product product : pack.getProducts()) {
                product.accept(this);
            }
        }
    }

    public int getCount() {
        return count;
    }

    public static int countItemsBelowMinPrice(Product product, BigDecimal minPrice) {
        CountItemsBelowMinPriceVisitor visitor = new CountItemsBelowMinPriceVisitor(minPrice);
        product.accept(visitor);
        return visitor.getCount();
    }
}
