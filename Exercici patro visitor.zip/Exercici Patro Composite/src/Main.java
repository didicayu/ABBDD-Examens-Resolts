import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        BigDecimal priceA = new BigDecimal("15");
        BigDecimal priceB = new BigDecimal("30");
        BigDecimal priceC = new BigDecimal("50");

        Item cola = new Item(priceA);
        Item penisDeGoma = new Item(priceB);
        Item blueLabelJohnnyWalker = new Item(priceC);

        Pack packA = new Pack();
        packA.addProduct(penisDeGoma);
        packA.addProduct(blueLabelJohnnyWalker);

        Pack packB = new Pack();
        packB.addProduct(cola);
        packB.addProduct(penisDeGoma);

        Pack packC = new Pack();
        packC.addProduct(blueLabelJohnnyWalker);
        packC.addProduct(cola);

        packA.addProduct(packB);
        packB.addProduct(packA);
        packA.addProduct(packA);

        // Pack A: penis, label, (packB): cola

//        Set<Product> visitedProducts = new HashSet<>();
//        long totalPrice = packA.countItemsBelowMinPrice(new BigDecimal("50"), visitedProducts);
//        System.out.println("Result: " + totalPrice);
//
//        System.out.println("Penis price: " + penisDeGoma.getPrice());
//        System.out.println("PackC price: " + packC.getPrice());

        Pack pack1 = new Pack();
        Pack pack2 = new Pack();
        Pack pack3 = new Pack();

        Item i1 = new Item(priceA);
        Item i2 = new Item(priceA);
        Item i3 = new Item(priceA);
        Item i4 = new Item(priceA);

        pack2.addProduct(i1);
        pack2.addProduct(i2);

        pack3.addProduct(i3);
        pack3.addProduct(i4);

        pack1.addProduct(pack2);
        pack1.addProduct(pack3);

//        long total = pack1.countItemsBelowMinPrice(new BigDecimal("50"));
//        System.out.println("Result: " + total);

        testMinPriceVisitor();
        testCountBelowMinVisitor();
    }

    public static void testMinPriceVisitor(){
        Item item1 = new Item(new BigDecimal("5.00"));
        Item item2 = new Item(new BigDecimal("15.00"));
        Pack pack = new Pack();
        pack.addProduct(item1);
        pack.addProduct(item2);

        BigDecimal minPrice = new BigDecimal("10.00");
        MinPriceUpdaterVisitor.updatePrices(pack, minPrice);

        System.out.println("Item 1 price: " + item1.getPrice()); // Ha de ser 10.0
        System.out.println("Item 2 price: " + item2.getPrice()); // Ha de ser 15.00
        System.out.println("Pack price: " + pack.getPrice()); // Ha de ser 25.00 (10.00 + 15.00)
    }

    public static void testCountBelowMinVisitor(){
        Item item1 = new Item(new BigDecimal("5.00"));
        Item item2 = new Item(new BigDecimal("15.00"));
        Pack pack1 = new Pack();
        pack1.addProduct(item1);
        pack1.addProduct(item2);

        Pack pack2 = new Pack();
        pack2.addProduct(pack1);
        pack2.addProduct(new Item(new BigDecimal("8.00")));

        BigDecimal minPrice = new BigDecimal("10.00");
        int count = CountItemsBelowMinPriceVisitor.countItemsBelowMinPrice(pack2, minPrice);

        System.out.println("Number of items below " + minPrice + ": " + count); // Ha de ser 2
    }

}